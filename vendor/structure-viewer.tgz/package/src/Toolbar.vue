<script lang="ts" setup>
import type { ListOption } from "@platforma-sdk/ui-vue";
import { PlBtnGhost, PlDropdown, PlIcon24 } from "@platforma-sdk/ui-vue";
import { useCssModule } from "vue";

import type { ColorThemeName, RepresentationType } from "./types.ts";

const { canExport } = defineProps<{
  canExport: boolean;
}>();

const emit = defineEmits<{
  export: [];
}>();

const representationType = defineModel<RepresentationType>("representationType", {
  required: true,
});

const colorTheme = defineModel<ColorThemeName>("colorTheme", {
  required: true,
});

const representationOptions: ListOption<RepresentationType>[] = [
  { label: "Cartoon", value: "cartoon" },
  { label: "Ball & Stick", value: "ball-and-stick" },
  { label: "Gaussian Surface", value: "gaussian-surface" },
  { label: "Putty", value: "putty" },
];

const colorOptions: ListOption<ColorThemeName>[] = [
  { label: "Chain Id", value: "chain-id" },
  { label: "Residue Name", value: "residue-name" },
  { label: "Uncertainty/Disorder", value: "uncertainty" },
  { label: "Hydrophobicity", value: "hydrophobicity" },
  { label: "Secondary Structure", value: "secondary-structure" },
  { label: "Sequence Id", value: "sequence-id" },
  { label: "Uniform", value: "uniform" },
];

const styles = useCssModule();
</script>

<template>
  <div :class="styles.toolbar">
    <PlDropdown
      v-model="representationType"
      :options="representationOptions"
      label="Representation"
      :class="styles.dropdown"
    />
    <PlDropdown
      v-model="colorTheme"
      :options="colorOptions"
      label="Coloring"
      :class="styles.dropdown"
    />
    <PlBtnGhost :disabled="!canExport" @click="emit('export')">
      Export
      <template #append>
        <PlIcon24 name="download" />
      </template>
    </PlBtnGhost>
  </div>
</template>

<style module>
.toolbar {
  display: flex;
  flex-wrap: wrap;
  gap: 12px;
}

.dropdown {
  min-inline-size: 216px;
}
</style>
