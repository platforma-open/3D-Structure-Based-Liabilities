import type { LocalBlobHandle, RemoteBlobHandle } from "@platforma-sdk/model";
import { getRawPlatformaInstance } from "@platforma-sdk/model";
import type { Structure } from "molstar/lib/mol-model/structure";
import { StructureElement, StructureProperties, Unit } from "molstar/lib/mol-model/structure";
import {
  createStructureColorThemeParams,
  createStructureRepresentationParams,
} from "molstar/lib/mol-plugin-state/helpers/structure-representation-params";
import { PolymerSequenceWrapper } from "molstar/lib/mol-plugin-ui/sequence/polymer";
import { PluginBehaviors } from "molstar/lib/mol-plugin/behavior";
import { PluginContext } from "molstar/lib/mol-plugin/context";
import { PluginSpec } from "molstar/lib/mol-plugin/spec";
import type { Representation } from "molstar/lib/mol-repr/representation";
import type { MarkerAction } from "molstar/lib/mol-util/marker-action";
import type { Ref, ShallowRef } from "vue";
import { onWatcherCleanup, shallowRef, watch, watchEffect } from "vue";

import type { ChainStrip, ChainStripResidue, ColorThemeName, RepresentationType } from "./types.ts";
import { rafThrottle, run, StaleOpError } from "./utils.ts";

interface UseStructureViewerOptions {
  parentEl: Readonly<ShallowRef<HTMLDivElement | null>>;
  canvasEl: Readonly<ShallowRef<HTMLCanvasElement | null>>;
  handle: () => LocalBlobHandle | RemoteBlobHandle;
  fileName: () => string;
  representationType: Ref<RepresentationType>;
  colorTheme: Ref<ColorThemeName>;
}

const SEQUENCE_NUMBER_PERIOD = 10;
const SEQUENCE_NUMBER_WIDTH = 5;

/** Tag emitted by `tryCreateComponentStatic` for the polymer component:
 *  `structure-component-${'static-polymer'}` (see
 *  `mol-plugin-state/builder/structure.ts:120`). Used to discriminate
 *  user-toggleable representation from preset-default ligand/water/etc. */
const POLYMER_COMPONENT_TAG = "structure-component-static-polymer";

function buildStrip(
  structure: Structure,
  wrapper: PolymerSequenceWrapper,
  chainLabel: string,
): ChainStrip {
  const residues: ChainStripResidue[] = [];
  const numbers = new Map<number, string>();
  const numberLocation = StructureElement.Location.create(structure);
  for (let idx = 0; idx < wrapper.length; idx++) {
    if (idx % SEQUENCE_NUMBER_PERIOD === 0) {
      numbers.set(idx, padSequenceNumber(getSequenceNumber(wrapper, idx, numberLocation)));
    }
    residues.push({ label: wrapper.residueLabel(idx), idx });
  }
  return { chainLabel, residues, numbers, wrapper };
}

/** Faithful port of `mol-plugin-ui/sequence/sequence.tsx:263` `getSequenceNumber`:
 *  atomic units use `auth_seq_id` + insertion code; coarse units use 1-based
 *  index; anything else returns empty (caller pads to fixed width). */
function getSequenceNumber(
  wrapper: PolymerSequenceWrapper,
  idx: number,
  location: StructureElement.Location,
): string {
  const loci = wrapper.getLoci(idx);
  const first = StructureElement.Loci.getFirstLocation(loci, location);
  if (!first) return "";
  if (Unit.isAtomic(first.unit)) {
    const seqId = StructureProperties.residue.auth_seq_id(first);
    const insCode = StructureProperties.residue.pdbx_PDB_ins_code(first);
    return `${seqId}${insCode || ""}`;
  }
  if (Unit.isCoarse(first.unit)) return `${idx + 1}`;
  return "";
}

function padSequenceNumber(text: string): string {
  if (text.length >= SEQUENCE_NUMBER_WIDTH) return text;
  return text + "\u00A0".repeat(SEQUENCE_NUMBER_WIDTH - text.length);
}

export function useStructureViewer(options: UseStructureViewerOptions) {
  const { parentEl, canvasEl, handle, fileName, representationType, colorTheme } = options;

  const hasContent = shallowRef(false);
  const error = shallowRef<string>();
  /** Strings emitted by molstar's label providers; may contain HTML like
   *  `<small>`, so consumers should render with v-html. */
  const hoverLabels = shallowRef<string[]>([]);
  const chainStrips = shallowRef<ChainStrip[]>([]);
  /** Reactivity bridge for the wrapper's `markerArray` (plain mutable state):
   *  bumped on every marker change so `isResidueHighlighted` re-evaluates. */
  const markerVersion = shallowRef(Symbol());

  let plugin: PluginContext | undefined;
  let bytes: Uint8Array | undefined;
  let labelsSub: { unsubscribe: () => void } | undefined;
  let highlightProvider: ((mark: Representation.Loci, action: MarkerAction) => void) | undefined;

  function reportError(label: string, err: unknown) {
    if (err instanceof StaleOpError) return;
    console.error(`[useStructureViewer] ${label}`, err);
    error.value = err instanceof Error ? err.message || err.name : String(err);
  }

  function dispose() {
    load.abort();
    hoverHighlight.cancel();
    labelsSub?.unsubscribe();
    labelsSub = undefined;
    if (highlightProvider) {
      plugin?.managers.interactivity.lociHighlights.removeProvider(highlightProvider);
      highlightProvider = undefined;
    }
    plugin?.dispose();
    plugin = undefined;
    bytes = undefined;
  }

  watchEffect(async function init() {
    const parent = parentEl.value;
    const canvas = canvasEl.value;
    if (!parent || !canvas) return;
    onWatcherCleanup(dispose);
    try {
      const spec: PluginSpec = {
        behaviors: [
          PluginSpec.Behavior(PluginBehaviors.Representation.HighlightLoci),
          PluginSpec.Behavior(PluginBehaviors.Representation.DefaultLociLabelProvider),
          PluginSpec.Behavior(PluginBehaviors.Camera.FocusLoci),
          PluginSpec.Behavior(PluginBehaviors.Camera.CameraControls),
          PluginSpec.Behavior(PluginBehaviors.Camera.CameraAxisHelper),
          PluginSpec.Behavior(PluginBehaviors.CustomProps.SecondaryStructure),
        ],
      };
      const p = new PluginContext(spec);
      await p.init();
      if (!(await p.initViewerAsync(canvas, parent))) {
        p.dispose();
        throw new Error("Failed to initialize Mol* WebGL viewer.");
      }
      plugin = p;
      labelsSub = plugin.behaviors.labels.highlight.subscribe(({ labels }) => {
        hoverLabels.value = labels.filter((label): label is string => typeof label === "string");
      });
      highlightProvider = (mark, action) => onLociMark(mark.loci, action);
      plugin.managers.interactivity.lociHighlights.addProvider(highlightProvider);
      await load();
    } catch (error) {
      reportError("attach failed", error);
    }
  });

  watch(handle, () => void load());
  watch([representationType, colorTheme], () => void applyRepresentation());

  const load = run(async (step) => {
    if (!plugin) return;
    bytes = undefined;
    hasContent.value = false;
    error.value = undefined;
    try {
      const fetched = await step(getRawPlatformaInstance().blobDriver.getContent(handle()));
      bytes = fetched;
      await step(plugin.clear());
      const text = new TextDecoder().decode(fetched);
      const data = await step(plugin.builders.data.rawData({ data: text }));
      const trajectory = await step(plugin.builders.structure.parseTrajectory(data, "pdb"));
      const presetResult = plugin.builders.structure.hierarchy.applyPreset(trajectory, "default");
      if (presetResult) await step(presetResult);
      await applyRepresentation();
      buildSequenceStrips();
      hasContent.value = true;
    } catch (error) {
      reportError("load failed", error);
    }
  });

  /** Mirrors molstar's State Tree "Update 3D Representation" / "Set Coloring"
   *  paths (`state.build().to(ref).update(params).commit()`), batched across
   *  every representation cell in one commit.
   *
   *  Component-kind aware: the user's representation type only makes sense for
   *  polymer atoms — applying e.g. cartoon to a ligand or water component would
   *  blank it out. Polymer components get both type + color updated; all other
   *  components (ligand, water, branched, ion, ...) keep their preset type and
   *  only have their color theme refreshed. */
  async function applyRepresentation() {
    if (!plugin) return;
    const update = plugin.state.data.build();
    let touched = false;
    for (const structure of plugin.managers.structure.hierarchy.current.structures) {
      const data = structure.cell.obj?.data;
      if (!data) continue;
      for (const component of structure.components) {
        const isPolymer = component.cell.transform.tags?.includes(POLYMER_COMPONENT_TAG) ?? false;
        for (const representation of component.representations) {
          if (isPolymer) {
            update.to(representation.cell).update(
              createStructureRepresentationParams(plugin, data, {
                type: representationType.value,
                color: colorTheme.value,
              }),
            );
          } else {
            const currentTypeName = representation.cell.transform.params?.type?.name;
            if (typeof currentTypeName !== "string") continue;
            const colorThemeParams = createStructureColorThemeParams(
              plugin,
              data,
              currentTypeName,
              colorTheme.value,
            );
            update.to(representation.cell).update((previous) => {
              previous.colorTheme = colorThemeParams;
            });
          }
          touched = true;
        }
      }
    }
    if (!touched) return;
    try {
      await update.commit();
    } catch (error) {
      reportError("apply representation failed", error);
    }
  }

  /** Builds one strip per polymer chain. Scoped to atomic polymer units
   *  grouped by `chainGroupId`, which covers the in-scope inputs (single-model
   *  ImmuneBuilder antibody PDBs). Crystallographic operators, NMR ensembles,
   *  ligand sequences, and overflow fallbacks (`ChainSequenceWrapper` /
   *  `ElementSequenceWrapper` for >5000 residues) are out of scope; revisit
   *  if generic PDBs ever land here. */
  function buildSequenceStrips() {
    markerVersion.value = Symbol();
    if (!plugin) {
      chainStrips.value = [];
      return;
    }
    const strips: ChainStrip[] = [];
    for (const structureRef of plugin.managers.structure.hierarchy.current.structures) {
      const structure = structureRef.cell.obj?.data;
      if (!structure) continue;
      const unitsByChain = new Map<number, Unit.Atomic[]>();
      for (const unit of structure.units) {
        if (!Unit.isAtomic(unit)) continue;
        if (unit.polymerElements.length === 0) continue;
        const existing = unitsByChain.get(unit.chainGroupId) ?? [];
        existing.push(unit);
        unitsByChain.set(unit.chainGroupId, existing);
      }
      for (const units of unitsByChain.values()) {
        const wrapper = new PolymerSequenceWrapper({ structure, units });
        const location = StructureElement.Location.create(
          structure,
          units[0],
          units[0].elements[0],
        );
        const chainLabel = StructureProperties.chain.auth_asym_id(location);
        strips.push(buildStrip(structure, wrapper, chainLabel));
      }
    }
    chainStrips.value = strips;
  }

  /** Provider for `lociHighlights`. Called externally by molstar whenever
   *  any source highlights a loci; we update each strip's marker bitmap and
   *  nudge `markerVersion` so dependent bindings re-evaluate. */
  function onLociMark(loci: Representation.Loci["loci"], action: MarkerAction) {
    let changed = false;
    for (const strip of chainStrips.value) {
      if (strip.wrapper.markResidue(loci, action)) changed = true;
    }
    if (changed) markerVersion.value = Symbol();
  }

  function isResidueHighlighted(strip: ChainStrip, idx: number): boolean {
    void markerVersion.value;
    return strip.wrapper.isHighlighted(idx);
  }

  const hoverHighlight = rafThrottle((strip: ChainStrip, idx: number) => {
    if (!plugin) return;
    const loci = strip.wrapper.getLoci(idx);
    plugin.managers.interactivity.lociHighlights.highlightOnly({ loci });
  });

  function onResidueHover(strip: ChainStrip, idx: number) {
    hoverHighlight(strip, idx);
  }

  function onResidueLeave() {
    hoverHighlight.cancel();
    plugin?.managers.interactivity.lociHighlights.clearHighlights();
  }

  function onResidueClick(strip: ChainStrip, idx: number) {
    if (!plugin) return;
    const loci = strip.wrapper.getLoci(idx);
    plugin.managers.camera.focusLoci(loci);
  }

  async function exportPdb() {
    if (!bytes) return;
    try {
      const fileHandle = await window.showSaveFilePicker({
        types: [
          {
            description: "PDB structure",
            accept: { "chemical/x-pdb": [".pdb"] },
          },
        ],
        suggestedName: fileName(),
      });
      const writable = await fileHandle.createWritable();
      // `slice()` produces a `Uint8Array<ArrayBuffer>`; the FS Access write API
      // rejects the broader `Uint8Array<ArrayBufferLike>` because the underlying
      // buffer might be a `SharedArrayBuffer`.
      await writable.write(bytes.slice());
      await writable.close();
    } catch (error) {
      if (error instanceof DOMException && error.name === "AbortError") return;
      reportError("export failed", error);
    }
  }

  return {
    hasContent,
    error,
    hoverLabels,
    chainStrips,
    isResidueHighlighted,
    onResidueHover,
    onResidueLeave,
    onResidueClick,
    exportPdb,
  };
}
