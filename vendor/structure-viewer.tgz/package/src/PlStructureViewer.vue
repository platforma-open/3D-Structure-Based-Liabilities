<script lang="ts" setup>
import { PlAlert } from "@platforma-sdk/ui-vue";
import { shallowRef, useCssModule, useTemplateRef } from "vue";

import SequenceStrip from "./SequenceStrip.vue";
import Toolbar from "./Toolbar.vue";
import type { ColorThemeName, PlStructureViewerProps, RepresentationType } from "./types.ts";
import { useStructureViewer } from "./useStructureViewer.ts";

const {
  handle,
  fileName = "structure.pdb",
  initialColorScheme = "chain-id",
} = defineProps<PlStructureViewerProps>();

const parentEl = useTemplateRef("parentEl");
const canvasEl = useTemplateRef("canvasEl");
const representationType = shallowRef<RepresentationType>("cartoon");
const colorTheme = shallowRef<ColorThemeName>(initialColorScheme);

const styles = useCssModule();

const {
  hasContent,
  error,
  hoverLabels,
  chainStrips,
  isResidueHighlighted,
  onResidueHover,
  onResidueLeave,
  onResidueClick,
  exportPdb,
} = useStructureViewer({
  parentEl,
  canvasEl,
  handle: () => handle,
  fileName: () => fileName,
  representationType,
  colorTheme,
});
</script>

<template>
  <div :class="styles.root">
    <Toolbar
      v-model:representation-type="representationType"
      v-model:color-theme="colorTheme"
      :can-export="hasContent"
      @export="exportPdb"
    />
    <PlAlert v-if="error" type="warn" closable @close="error = undefined">
      {{ error }}
    </PlAlert>
    <div v-if="chainStrips.length > 0" :class="styles.sequence">
      <SequenceStrip
        v-for="(strip, stripIdx) in chainStrips"
        :key="stripIdx"
        :strip
        :is-highlighted="(idx) => isResidueHighlighted(strip, idx)"
        @hover="onResidueHover(strip, $event)"
        @leave="onResidueLeave"
        @click="onResidueClick(strip, $event)"
      />
    </div>
    <div ref="parentEl" :class="styles.canvasParent">
      <canvas ref="canvasEl" :class="styles.canvas" />
      <div v-if="hoverLabels.length > 0" :class="styles.hoverInfo">
        <div v-for="(label, idx) in hoverLabels" :key="idx" v-html="label" />
      </div>
    </div>
  </div>
</template>

<style module>
.root {
  display: flex;
  flex-direction: column;
  flex: 1;
  gap: 12px;
}

.canvasParent {
  position: relative;
  flex: auto;
}

.canvas {
  position: absolute;
  inset: 0;
}

.sequence {
  display: flex;
  flex-direction: column;
  gap: 8px;
  padding-block: 4px;
}

.hoverInfo {
  position: absolute;
  inset-block-end: 12px;
  inset-inline-end: 12px;
  max-inline-size: 50%;
  padding-block: 8px;
  padding-inline: 12px;
  background: color-mix(in srgb, var(--bg-base-dark) 70%, transparent);
  color: var(--txt-00);
  border-radius: 4px;
  pointer-events: none;
  line-height: 1.4;
}
</style>
