/** Thrown by `step()` when its `run()` invocation has been superseded. */
export class StaleOpError extends Error {}

/**
 * Wrap an async `body` so subsequent calls supersede in-flight prior ones.
 * Each invocation:
 *   - swaps an internal token, so any prior body checking the token via `step()`
 *     learns it's been superseded and short-circuits at its next await;
 *   - waits for the previous body to settle before running, so its mutations
 *     don't interleave with the previous body's.
 * `.abort()` swaps the token without invoking `body` — used during teardown.
 */
export function run<Args extends unknown[], T>(
  body: (step: <U>(work: Promise<U>) => Promise<U>, ...args: Args) => Promise<T>,
) {
  let token: symbol = Symbol();
  let chain: Promise<void> = Promise.resolve();
  async function invoke(...args: Args): Promise<T | undefined> {
    const local = (token = Symbol());
    const previous = chain;
    const { promise, resolve: release } = Promise.withResolvers<void>();
    chain = promise;
    try {
      try {
        await previous;
      } catch {
        // Previous body's failure shouldn't block the next one.
      }
      if (local !== token) return undefined;
      const step = async <U>(work: Promise<U>): Promise<U> => {
        const result = await work;
        if (local !== token) throw new StaleOpError();
        return result;
      };
      return await body(step, ...args);
    } finally {
      release();
    }
  }
  invoke.abort = () => {
    token = Symbol();
  };
  return invoke;
}

/**
 * Coalesce calls to `fn` so it runs at most once per animation frame with the
 * most recent arguments. Returns the coalesced function with a `.cancel()`
 * method that drops any scheduled call.
 */
export function rafThrottle<Args extends unknown[]>(fn: (...args: Args) => void) {
  let frame: number | null = null;
  let pending: Args | null = null;
  function throttled(...args: Args) {
    pending = args;
    if (frame !== null) return;
    frame = requestAnimationFrame(() => {
      frame = null;
      const latest = pending;
      pending = null;
      if (latest) fn(...latest);
    });
  }
  throttled.cancel = () => {
    if (frame !== null) {
      cancelAnimationFrame(frame);
      frame = null;
    }
    pending = null;
  };
  return throttled;
}
