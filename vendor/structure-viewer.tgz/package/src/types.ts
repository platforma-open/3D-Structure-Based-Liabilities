import type { LocalBlobHandle, RemoteBlobHandle } from "@platforma-sdk/model";
import type { PolymerSequenceWrapper } from "molstar/lib/mol-plugin-ui/sequence/polymer";

export interface PlStructureViewerProps {
  handle: LocalBlobHandle | RemoteBlobHandle;
  fileName?: string;
  initialColorScheme?: ColorThemeName;
}

export type RepresentationType = "cartoon" | "ball-and-stick" | "gaussian-surface" | "putty";

export type ColorThemeName =
  | "chain-id"
  | "residue-name"
  | "uncertainty"
  | "hydrophobicity"
  | "secondary-structure"
  | "sequence-id"
  | "uniform";

export interface ChainStripResidue {
  label: string;
  idx: number;
}

export interface ChainStrip {
  chainLabel: string;
  residues: ChainStripResidue[];
  /** Sparse: residue index → padded `auth_seq_id` text, present only at every Nth index. */
  numbers: Map<number, string>;
  wrapper: PolymerSequenceWrapper;
}
