<script lang="ts" setup>
import { useCssModule } from "vue";

import type { ChainStrip } from "./types.ts";

const { strip, isHighlighted } = defineProps<{
  strip: ChainStrip;
  /** Returns whether the residue at `idx` should render as highlighted. */
  isHighlighted: (idx: number) => boolean;
}>();

const emit = defineEmits<{
  hover: [idx: number];
  leave: [];
  click: [idx: number];
}>();

const styles = useCssModule();
</script>

<template>
  <div :class="styles.chainStrip">
    <span :class="styles.chainLabel">
      {{ strip.chainLabel }}
    </span>
    <template v-for="residue in strip.residues" :key="residue.idx">
      <span v-if="strip.numbers.has(residue.idx)" :class="styles.seqNumber">
        {{ strip.numbers.get(residue.idx) }}
      </span>
      <span
        :class="[styles.residue, { [styles.residueHighlighted]: isHighlighted(residue.idx) }]"
        @mouseenter="emit('hover', residue.idx)"
        @mouseleave="emit('leave')"
        @click="emit('click', residue.idx)"
      >
        {{ residue.label }}
      </span>
    </template>
  </div>
</template>

<style module>
.chainStrip {
  /* Inline flow so residues + number markers wrap as one block of text.
     Tall `line-height` reserves vertical room above each line so floated
     `.seqNumber` (offset upward by 1.1em) lands in empty space instead of
     crashing into the previous wrapped line. Mirrors the 22px line-height
     upstream uses in `msp-sequence-wrapper-non-empty`. */
  line-height: 2;
  word-break: break-all;
  overflow-wrap: anywhere;
  font-family: var(--font-family-monospace);
  font-size: 12px;
}

.chainLabel {
  font-weight: bold;
  margin-inline-end: 8px;
}

.seqNumber {
  /* Float number above the strip; consumes 0 horizontal flow space.
     Mirrors mol-plugin-ui/skin/base/components/sequence.scss:105 — the
     -3em margin cancels the number's text width so it doesn't push residues,
     then translates the visual rendering up + slightly right. */
  position: relative;
  inset-block-start: -1.1em;
  inset-inline-start: 3.1em;
  margin-inline-start: -3em;
  font-size: 80%;
  color: var(--txt-03);
  pointer-events: none;
  word-break: keep-all;
}

.residue {
  cursor: pointer;
  user-select: none;
}

.residue:hover,
.residueHighlighted {
  background-color: var(--border-color-focus);
}
</style>
