import { vue } from "@milaboratories/eslint-config";

/** @type {import('eslint').Linter.Config[]} */
export default [
  ...vue,
  {
    rules: {
      "@stylistic/quotes": "off",
    },
  },
];
