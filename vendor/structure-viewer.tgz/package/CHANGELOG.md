# @milaboratories/structure-viewer

## 0.2.0

### Minor Changes

- 2289f8c: Add representation and coloring dropdowns, a tooltip on residue hover, and a per-chain sequence strip with bidirectional highlight sync to the 3D view.

## 0.1.0

### Minor Changes

- 40420aa: Initial release. Vue component wrapping Mol* (molstar) for 3D macromolecular structure viewing inside Platforma blocks. Takes a `LocalBlobHandle | RemoteBlobHandle` plus an optional filename; renders the structure on a Mol* canvas and exposes an Export button that writes the PDB to a user-chosen path via the File System Access API.
