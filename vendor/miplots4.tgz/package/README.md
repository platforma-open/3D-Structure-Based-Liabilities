# MiPlots 4 #

* TODO add description

### Install ###

`pnpm install`

### Build and install locally ###

`pnpm run build && pnpm do-pack`

This command will generate a .tgz file at the directory's root: ./package.tgz

It can be installed in another project using 'overrides' in package.json:
```
"pnpm": {
    "overrides": {
        "@milaboratories/miplots4": "/path/to/folder/visualizations/packages/miplots4/package.tgz"
     }
}
```
